package com.example.philip.testmenu;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void openMap(View view)
    {
        Intent map = new Intent(this, MapsActivity.class);
        startActivity(map);
    }

    public void openEvents(View view)
    {
        Intent event = new Intent(this,Events.class);
        startActivity(event);
    }

    public void comingSoon(View view)
    {
        Context context = getApplicationContext();
        CharSequence text = "Coming soon!";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

    }

}
